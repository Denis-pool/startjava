//non-compiled with javac: Compilable with Java17
package com.puppycrawl.tools.checkstyle.checks.sizes.recordcomponentname;

/* Config: default
 */
public record InputXpathRecordComponentNameDefault(int _value) { // warn

}
