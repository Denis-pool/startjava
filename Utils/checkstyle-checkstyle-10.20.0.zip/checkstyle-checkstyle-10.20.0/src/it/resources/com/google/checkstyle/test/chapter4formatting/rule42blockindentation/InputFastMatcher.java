package com.google.checkstyle.test.chapter4formatting.rule42blockindentation;

/** some javadoc. */
public class InputFastMatcher {

  /** some javadoc. */
  public boolean matches(char c) {
    // OOOO Auto-generated method stub
    return false;
  }

  /** some javadoc. */
  public String replaceFrom(CharSequence sequence, CharSequence replacement) {
    // OOOO Auto-generated method stub
    return null;
  }

  /** some javadoc. */
  public String collapseFrom(CharSequence sequence, char replacement) {
    // OOOO Auto-generated method stub
    return null;
  }

  /** some javadoc. */
  public String trimFrom(CharSequence s) {
    // OOOO Auto-generated method stub
    return null;
  }

  /** some javadoc. */
  public String trimLeadingFrom(CharSequence sequence) {
    // OOOO Auto-generated method stub
    return null;
  }

  /** some javadoc. */
  public String trimTrailingFrom(CharSequence sequence) {
    // OOOO Auto-generated method stub
    return null;
  }
}
