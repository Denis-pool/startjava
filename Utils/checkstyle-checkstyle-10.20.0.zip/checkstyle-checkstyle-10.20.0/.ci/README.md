# Continuous integration

ATTENTION:
  All scripts in this folder expect to be launched from root folder of repository

Example of usage:
  ./.ci/validation.sh all-sevntu-checks

  export TRAVIS_PULL_REQUEST="" && ./.ci/validation.sh releasenotes-gen
